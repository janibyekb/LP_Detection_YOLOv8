# Car Speed > 2024-03-11 5:15pm
https://universe.roboflow.com/speed-estimation/car-speed-bitij

Provided by a Roboflow user
License: CC BY 4.0

